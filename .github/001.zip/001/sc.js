// script.js

// 示例商品数据
const products = [
  { id: 1, name: '商品A', price: 100, image: 'img/banner/1.jpg' },
  { id: 2, name: '商品B', price: 200, image: 'img/banner/2.jpg' },
  { id: 3, name: '商品3', price: 300, image: 'img/slider/slider-1/1.jpg' },
  { id: 4, name: '商品4', price: 400, image: 'img/slider/slider-1/2.jpg' },
  { id: 5, name: '商品5', price: 500, image: 'img/slider/slider-1/3.jpg' },


  { id: 6, name: '商品6', price: 600, image: 'img/slider/slider-2/1.jpg' },
  { id: 7, name: '商品7', price: 700, image: 'img/slider/slider-2/2.jpg' },
  { id: 8, name: '商品8', price: 800, image: 'img/slider/slider-2/3.jpg' },
  { id: 9, name: '商品9', price: 900, image: 'img/banner/3.jpg' },
  { id: 10, name: '商品10', price: 1000, image: 'img/banner/4.jpg' },
  { id: 11, name: '商品11', price: 1100, image: 'img/product/6.jpg' },
  // 更多商品...
];

// 购物车对象
const cart = {
  items: [],
  totalPrice: 0,
  addProduct(product) {
      const cartItem = this.items.find(item => item.id === product.id);
      if (cartItem) {
          cartItem.quantity++;
      } else {
          this.items.push({ ...product, quantity: 1 });
      }
      this.updateTotalPrice();
  },
  updateTotalPrice() {
      this.totalPrice = this.items.reduce((total, item) => total + item.price * item.quantity, 0);
      document.querySelector('.total-price').textContent = this.totalPrice;
  }
};

// 初始化购物车总价
cart.updateTotalPrice();

// 添加商品到购物车
function addToCart(productId) {
  const product = products.find(product => product.id === productId);
  cart.addProduct(product);
  updateCartDisplay();
}



// 页面加载完成后初始化
window.onload = () => {
  initProductList();
};

// script.js

// ...之前的代码保持不变...

// 更新购物车显示，添加增减按钮
function updateCartDisplay() {
  const cartItemsList = document.querySelector('.cart-items');
  cartItemsList.innerHTML = '';
  cart.items.forEach(item => {
      const cartItem = document.createElement('li');
      cartItem.className = 'cart-item';
      cartItem.innerHTML = `
        <div class="cart-photo">
        <a href="#"><img src="${item.image}" alt=""/></a>
        </div>

        <div class="cart-info">
          <h2>${item.name}</h2>
          <p class="mb-0">价格 : ${item.price}</p>
          <p class="mb-0">数量 : ${item.quantity}</p>
          <button onclick="changeQuantity(${item.id}, -1)" style="font-size: 28px;">-</button>
          <button onclick="changeQuantity(${item.id}, 1)" style="font-size: 24px;">+</button>
        </div>
          
      `;
      cartItemsList.appendChild(cartItem);
  });
}


// 改变购物车中商品的数量
function changeQuantity(productId, quantityChange) {
  const item = cart.items.find(item => item.id === productId);
  if (item) {
      item.quantity += quantityChange;
      if (item.quantity <= 0) {
          cart.items = cart.items.filter(i => i.id !== productId);
      }
      cart.updateTotalPrice();
      updateCartDisplay();
  }
}

