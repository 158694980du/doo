// 模拟数据库存储
var usersDatabase = {};

function register() {
  var newUsername = document.getElementById('new-username').value;
  var newPassword = document.getElementById('new-password').value;
  var confirmPassword = document.getElementById('confirm-password').value;

  if (newPassword !== confirmPassword) {
    alert('两次输入的密码不一致！');
    return;
  }

  // 检查用户名是否已被注册
  if (usersDatabase[newUsername]) {
    alert('用户名已被注册！');
    return;
  }

  // 存储用户名和密码
  usersDatabase[newUsername] = newPassword;

  alert('注册成功！');
  // 注册成功后的逻辑处理，比如跳转到登录页面
  document.getElementById('register-form').style.display = 'none';
  document.getElementById('login-form').style.display = 'block';
}

function login() {
  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;

  // 检查用户名是否存在
  if (!usersDatabase[username]) {
    alert('用户名不存在！');
    return;
  }

  // 验证密码
  if (usersDatabase[username] === password) {
    alert('登录成功！');
    window.location.href = 'index.html'; // 跳转到主页面的URL
    // 登录成功后的逻辑处理，比如页面跳转
  } else {
    alert('密码错误！');
  }
}

function showRegisterForm() {
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('register-form').style.display = 'block';
}